<?php $this->view('includes/header'); ?>
<?php $this->view('includes/nav'); ?>
<div class="container-fluid">

</div>
<?php $this->view('includes/footer'); ?>
