<!doctype html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>主页</title>
    <link rel="stylesheet" href="<?=ROOT?>/asserts/bootstrap.css">
    <link rel="stylesheet" href="<?=ROOT?>/asserts/fontawesome-free-6.4.0-web/css/all.css">
    <script src="../../../public/asserts/bootstrap.bundle.js"></script>
</head>
<body>
<div style="min-width: 350px">

