<?php
const ROOT='http://localhost/public';
const DBNAME='school_db';
const DBHOST='localhost';
const DBPORT='3306';
const DBUSER='root';
const DBPASS='';
const DBRIVER='mysql';
const CLASSID='';