<?php
session_start();
require_once '../private/core/autoload.php';
//echo "这是我的主页";
$app=new App();